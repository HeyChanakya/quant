# Quantitative Trading Engine: Multi-Horizon Stacking Ensemble

## 📌 Project Overview
This repository contains the end-to-end implementation of a quantitative trading pipeline designed for the **Indian Equity Market (Nifty 50 universe)**. 

The core engine utilizes a **Multi-Horizon Stacking Ensemble** (CatBoost, XGBoost, LightGBM) to predict price directionality across 5, 10, and 20-day horizons. [cite_start]Unlike standard vector-based models, this project features a rigorous **Event-Driven Backtester** that accounts for realistic liquidity constraints, transaction costs (10bps), and market impact[cite: 1, 39].

### 🚀 Key Performance Metrics (Out-of-Sample Test Set)
| Metric | Strategy Result | Benchmark |
| :--- | :--- | :--- |
| **Total Return** | **+54.07%** | +39.56% |
| **Sharpe Ratio** | **1.277** | 0.85 |
| **Max Drawdown** | **-17.87%** | -22.40% |
| **Win Rate** | **56.6%** | N/A |

---

## 📂 Directory Structure

```text
├── data/
[cite_start]│   ├── raw/                     # Original anonymized OHLCV data (100 assets) [cite: 5]
│   └── processed/               # Cleaned data with 42 engineered features
│
├── notebooks/
[cite_start]│   ├── 1_data_cleaning.ipynb    # Data sanitation, winsorization, feature engineering [cite: 3]
[cite_start]│   ├── 2_model_engine.ipynb     # Stacking Ensemble training (CatBoost/XGB/LGBM) [cite: 20]
[cite_start]│   ├── 3_backtest_analysis.ipynb# Event-driven backtester & performance metrics [cite: 39]
[cite_start]│   └── 4_correlation.ipynb      # Statistical Arbitrage (Cointegration/ADF Tests) [cite: 55]
│
├── outputs/
│   ├── model_checkpoints/       # Saved .pkl models
│   ├── trade_logs/              # CSV logs of every executed trade
│   └── figures/                 # Equity curves, heatmaps, drawdown charts
│
[cite_start]├── precog.docx              # Detailed project documentation & failure analysis [cite: 1]
├── requirements.txt             # Python dependencies
└── README.md                    # Project documentation